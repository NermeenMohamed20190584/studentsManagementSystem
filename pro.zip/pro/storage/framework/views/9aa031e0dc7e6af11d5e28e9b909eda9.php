

<?php $__env->startSection('content'); ?>
    <h1>Students Management</h1>

    <body>
    <div class="row">
        <div class="col-md-6">
            <form action="<?php echo e(route('students.index')); ?>" method="get" class="mt-3" id="filterForm">
                <div class="form-group">
                    <label for="filter_level">Filter by Level:</label><br>
                    <select  id="filter_level" name="filter_level" class="form-control" onchange="document.getElementById('filterForm').submit();">
                        <option value="all">All</option>
                        <option value="1">Level 1</option>
                        <option value="2">Level 2</option>
                        <option value="3">Level 3</option>
                        <option value="4">Level 4</option>
                    </select>
                </div>
            </form>
        </div>
        
        <div class="col-md-6">
            <label for="filter_level">Search for student:</label>
            <form action="<?php echo e(route('students.index')); ?>" method="get" class="mt-3">
                <div class="input-group">
                    <input type="text" id="search_query" name="search_query" class="form-control" value="<?php echo e(old('search_query')); ?>" placeholder="Search by Code, Name, or Email" onkeydown="if (event.keyCode === 13) this.form.submit();">
                </div>
            </form>
        </div>
    </div>
    <table class="table">
        <thead>
            <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Date of birth</th>
                <th>Email</th>
                <th>Level</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($student->code); ?></td>
                    <td><?php echo e($student->full_name); ?></td>
                    <td><?php echo e($student->date_of_birth); ?></td>
                    <td><?php echo e($student->email); ?></td>
                    <td><?php echo e($student->level); ?></td>
                    
                    <td>
                        <a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-primary">Edit</a>
                        <form action="<?php echo e(route('students.destroy', $student->id)); ?>" method="post" style="display: inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <a href="<?php echo e(route('students.create')); ?>" class="btn btn-primary">Add Student</a>
    <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-primary">View Courses</a>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mangementSystem\resources\views/Student/displayStudent.blade.php ENDPATH**/ ?>